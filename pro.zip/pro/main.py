from fastapi import FastAPI, File
import efficientnet.tfkeras as efn
import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow_hub as hub
from tensorflow.keras.layers import Dense
from tensorflow.keras.models import Sequential
from tensorflow.keras.applications import imagenet_utils
from tensorflow.keras.layers import GlobalAveragePooling2D
from tensorflow_core.python.keras.layers import GlobalAveragePooling2D
from PIL import Image
import io

app = FastAPI()

def model_config(input_shape, classes):
    """
    transfer learning from imagenet's weights, using Google's efficientnet7 architecture
    top layer (include_top) is removed as the number of classes is changed
    """
    base = efn.EfficientNetB7(input_shape=input_shape, weights='imagenet', include_top=False)

    model = Sequential()
    model.add(base)
    model.add(GlobalAveragePooling2D())
    model.add(Dense(classes, activation='softmax'))
    model.compile(loss='categorical_crossentropy',
                optimizer='adam',
                metrics=['accuracy'])
    return model


@app.post("/uploadfile/")
async def create_upload_file(file: bytes = File(...)):
    model = model_config((100, 100, 3), 4)
    # model.summary()
    model = tf.keras.models.load_model('saved_model.h5', custom_objects={'KerasLayer': hub.KerasLayer})
    img = Image.open(io.BytesIO(file))
    img = img.resize((100, 100))
    img = np.array(img)
    img = np.expand_dims(img, axis=0)
    img = imagenet_utils.preprocess_input(img)
    predict_prob = model.predict(img)
    df_predict_prob = pd.DataFrame(predict_prob, columns=['healthy', 'multiple_diseases', 'rust', 'scab'])
    return df_predict_prob.to_json(orient='columns')
