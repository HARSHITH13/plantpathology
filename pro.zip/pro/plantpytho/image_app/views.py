import numpy
from keras_preprocessing import image
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework import status
from .serializers import FileSerializer

import efficientnet.tfkeras as efn
import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow_hub as hub
from tensorflow.keras.layers import Dense
from tensorflow.keras.models import Sequential
from tensorflow.keras.applications import imagenet_utils
from tensorflow_core.python.keras.layers import GlobalAveragePooling2D

def model_config(input_shape, classes):

    base = efn.EfficientNetB7(input_shape=input_shape, weights='imagenet', include_top=False)

    model = Sequential()
    model.add(base)
    model.add(GlobalAveragePooling2D())
    model.add(Dense(classes, activation='softmax'))
    model.compile(loss='categorical_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])
    return model


class FileView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        file_serializer = FileSerializer(data=request.data)
        model = tf.keras.models.load_model('saved_model.h5', custom_objects={'KerasLayer': hub.KerasLayer})

        if file_serializer.is_valid():
            file_serializer.save()
            file = file_serializer.validated_data['file']
            img = image.load_img(file, target_size=(100, 100))
            img = np.array(img)
            img = np.expand_dims(img, axis=0)
            predict_prob = model.predict(img)
            index = np.argmax(predict_prob)
            map_data = {0: 'healthy', 1: 'multiple_diseases', 2: 'rust', 3: 'scub'}
            stat = {'status':index}
            return Response(stat,status=status.HTTP_201_CREATED)
        else:
            return Response(file_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
