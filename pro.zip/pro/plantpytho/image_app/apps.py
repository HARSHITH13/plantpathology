from django.apps import AppConfig


class ImageAppConfig(AppConfig):
    name = 'image_app'
